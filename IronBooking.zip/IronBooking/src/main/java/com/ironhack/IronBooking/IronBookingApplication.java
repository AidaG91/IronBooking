package com.ironhack.IronBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IronBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(IronBookingApplication.class, args);
	}

}
